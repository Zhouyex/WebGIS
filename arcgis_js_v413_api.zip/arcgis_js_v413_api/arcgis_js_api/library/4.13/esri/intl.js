// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.13/esri/copyright.txt for details.
//>>built
define(["require","exports","./intl/date","./intl/number","./intl/substitute"],function(e,a,b,c,d){Object.defineProperty(a,"__esModule",{value:!0});a.formatDate=b.formatDate;a.convertDateFormatToIntlOptions=b.convertDateFormatToIntlOptions;a.formatNumber=c.formatNumber;a.convertNumberFormatToIntlOptions=c.convertNumberFormatToIntlOptions;a.substitute=d.substitute});