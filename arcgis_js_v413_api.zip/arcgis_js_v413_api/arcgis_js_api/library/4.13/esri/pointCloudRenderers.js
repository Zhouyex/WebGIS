// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.13/esri/copyright.txt for details.
//>>built
define("require exports ./renderers/PointCloudClassBreaksRenderer ./renderers/PointCloudRenderer ./renderers/PointCloudRGBRenderer ./renderers/PointCloudStretchRenderer ./renderers/PointCloudUniqueValueRenderer ./renderers/support/pointCloud/jsonUtils".split(" "),function(h,a,b,c,d,e,f,g){Object.defineProperty(a,"__esModule",{value:!0});a.PointCloudClassBreaksRenderer=b;a.BasePointCloudRenderer=c;a.PointCloudRGBRenderer=d;a.PointCloudStretchRenderer=e;a.PointCloudUniqueValueRenderer=f;a.isPointCloudRenderer=
function(b){return b instanceof a.BasePointCloudRenderer};a.fromJSON=g.fromJSON});