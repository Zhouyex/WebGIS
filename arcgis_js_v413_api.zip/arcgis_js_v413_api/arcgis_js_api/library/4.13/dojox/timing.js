//>>built
define(["./timing/_base"],function(a){return a});