//>>built
define(["dojo","dojox","dojox/math/_base"],function(b,a,c){b.getObject("math",!0,a);return a.math});