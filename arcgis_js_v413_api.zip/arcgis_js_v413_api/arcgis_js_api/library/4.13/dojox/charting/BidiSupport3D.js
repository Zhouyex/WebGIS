//>>built
define(["dojo/_base/kernel"],function(a){a.deprecated("dojox.charting.BidiSupport3D is deprecated,","set \"has: {'dojo-bidi': true }\" in data-dojo-config to enable bidi support")});