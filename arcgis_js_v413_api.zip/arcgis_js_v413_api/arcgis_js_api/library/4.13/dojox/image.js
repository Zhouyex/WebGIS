//>>built
define(["./image/_base"],function(a){return a});