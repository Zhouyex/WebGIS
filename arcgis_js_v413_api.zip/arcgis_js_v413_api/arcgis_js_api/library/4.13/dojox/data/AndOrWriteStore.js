//>>built
define(["dojo/_base/declare","dojo/data/ItemFileWriteStore","./AndOrReadStore"],function(a,b,c){return a("dojox.data.AndOrWriteStore",[b,c],{})});