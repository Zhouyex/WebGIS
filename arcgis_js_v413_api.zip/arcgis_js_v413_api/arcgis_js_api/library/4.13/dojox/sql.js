//>>built
define(["./sql/_base"],function(){});