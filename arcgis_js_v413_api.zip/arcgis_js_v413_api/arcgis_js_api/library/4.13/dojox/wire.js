//>>built
define(["./wire/_base"],function(){});