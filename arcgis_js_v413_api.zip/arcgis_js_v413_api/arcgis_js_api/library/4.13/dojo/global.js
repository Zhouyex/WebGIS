//>>built
define(function(){return"undefined"!==typeof global&&"function"!==typeof global?global:"undefined"!==typeof window?window:"undefined"!==typeof self?self:this});